//
//  ColorUtils.m
//  projectPhone
//
//  Created by apple on 17/12/2016.
//  Copyright © 2016 apple. All rights reserved.
//

#import "ColorUtils.h"

@implementation ColorUtils


+ (UIColor *) BgColor {
    // rgb color;
   // NSString *lol = @"hello";
    
    
   return [UIColor colorWithRed:(0)
                          green:(0)
                           blue:(0)
                          alpha:(1)
           ];
    
}

@end
